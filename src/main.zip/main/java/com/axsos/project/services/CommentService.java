package com.axsos.project.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.axsos.project.dto.CommentDTO;
import com.axsos.project.repositores.CommentRepository;


@Service
public class CommentService {
	@Autowired
	private CommentRepository commentRepository;

	// comments for a single product - shown on the Edit Product page
	public List<CommentDTO> getCommentsForProduct(Long productId) {
		return commentRepository.findByProductIdOrderByCreatedAtDesc(productId).stream()
				.map(CommentDTO::new)
				.collect(Collectors.toList());
	}

	// every comment across all of a store's products - shown on the Edit Store page
	public List<CommentDTO> getCommentsForStore(Long storeId) {
		return commentRepository.findByProduct_Store_IdOrderByCreatedAtDesc(storeId).stream()
				.map(CommentDTO::new)
				.collect(Collectors.toList());
	}
}
