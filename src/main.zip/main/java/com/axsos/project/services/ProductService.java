package com.axsos.project.services;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.axsos.project.dto.ProductDTO;
import com.axsos.project.dto.ProductForm;
import com.axsos.project.dto.ProductPageForm;
import com.axsos.project.models.Product;
import com.axsos.project.models.Store;
import com.axsos.project.repositores.OrderItemRepository;
import com.axsos.project.repositores.ProductRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private OrderItemRepository orderItemRepository;

	// all products for a store, each with its units-sold / revenue attached
	public List<ProductDTO> getProductsForStore(Long storeId) {
		return productRepository.findByStoreIdOrderByCreatedAtDesc(storeId).stream()
				.map(this::toDTO)
				.collect(Collectors.toList());
	}

	// fetch a single product, but only if it belongs to this store (ownership check)
	public Optional<Product> getOwnedProduct(Long productId, Long storeId) {
		if (productRepository.countByIdAndStoreId(productId, storeId) == 0) {
			return Optional.empty();
		}
		return productRepository.findById(productId);
	}

	public ProductDTO createProduct(ProductForm form, Store store) {
		Product product = new Product();
		applyForm(product, form);
		product.setStore(store);
		Product saved = productRepository.save(product);
		return toDTO(saved);
	}

	public Optional<ProductDTO> updateProduct(Long productId, ProductForm form, Long storeId) {
		Optional<Product> ownedProduct = getOwnedProduct(productId, storeId);
		if (ownedProduct.isEmpty()) {
			return Optional.empty();
		}
		Product product = ownedProduct.get();
		applyForm(product, form);
		Product saved = productRepository.save(product);
		return Optional.of(toDTO(saved));
	}

	public boolean deleteProduct(Long productId, Long storeId) {
		Optional<Product> ownedProduct = getOwnedProduct(productId, storeId);
		if (ownedProduct.isEmpty()) {
			return false;
		}
		productRepository.delete(ownedProduct.get());
		return true;
	}

	// used by the Add Product page - imageUrl is whatever FileStorageService returned, or null if no file was picked
	public Product createProductFromPage(ProductPageForm form, Store store, String imageUrl) {
		Product product = new Product();
		product.setProductName(form.getProductName());
		product.setDescription(form.getDescription());
		product.setPrice(form.getPrice());
		product.setQuantity(form.getQuantity());
		product.setImage(imageUrl);
		product.setStore(store);
		return productRepository.save(product);
	}

	// used by the Edit Product page - pass imageUrl == null to keep the existing image
	public Optional<Product> updateProductFromPage(Long productId, ProductPageForm form, Long storeId,
			String imageUrl) {
		Optional<Product> ownedProduct = getOwnedProduct(productId, storeId);
		if (ownedProduct.isEmpty()) {
			return Optional.empty();
		}
		Product product = ownedProduct.get();
		product.setProductName(form.getProductName());
		product.setDescription(form.getDescription());
		product.setPrice(form.getPrice());
		product.setQuantity(form.getQuantity());
		if (imageUrl != null) {
			product.setImage(imageUrl);
		}
		return Optional.of(productRepository.save(product));
	}

	private void applyForm(Product product, ProductForm form) {
		product.setProductName(form.getProductName());
		product.setDescription(form.getDescription());
		product.setPrice(form.getPrice());
		product.setImage(form.getImage());
		product.setQuantity(form.getQuantity());
	}

	public ProductDTO toDTO(Product product) {
		Long unitsSold = orderItemRepository.sumQuantityByProductId(product.getId());
		Double revenue = orderItemRepository.sumRevenueByProductId(product.getId());
		return new ProductDTO(product.getId(), product.getProductName(), product.getDescription(),
				product.getPrice(), product.getImage(), product.getQuantity(), product.getCreatedAt(),
				unitsSold, revenue);
	}
}
