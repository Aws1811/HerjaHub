package com.axsos.project.repositores;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.axsos.project.models.Comment;

@Repository
public interface CommentRepository extends JpaRepository<Comment, Long> {

	// comments left on a single product (shown on the Edit Product page)
	List<Comment> findByProductIdOrderByCreatedAtDesc(Long productId);

	// every comment across all of a store's products (shown on the Edit Store page)
	List<Comment> findByProduct_Store_IdOrderByCreatedAtDesc(Long storeId);
}
