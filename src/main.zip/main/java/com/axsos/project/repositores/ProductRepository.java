package com.axsos.project.repositores;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.axsos.project.models.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
	List<Product> findByStoreIdOrderByCreatedAtDesc(Long storeId);

	// used for ownership checks (product must belong to the logged in store)
	long countByIdAndStoreId(Long id, Long storeId);
}
